(function(){
var main=document.getElementById("contenido"),menu=document.getElementById("menu"),burger=document.querySelector(".burger");
burger.addEventListener("click",function(){var o=menu.classList.toggle("open");burger.setAttribute("aria-expanded",o)});
function setActive(url){var f=url.split("/").pop()||"index.html";if(f==="doctores.html")f="index.html";
document.querySelectorAll("nav a").forEach(function(a){a.classList.toggle("active",a.getAttribute("href")===f)})}
function load(url,push){fetch(url).then(function(r){if(!r.ok)throw 0;return r.text()}).then(function(t){
var d=new DOMParser().parseFromString(t,"text/html");main.innerHTML=d.getElementById("contenido").innerHTML;document.title=d.title;
if(push)history.pushState({},"",url);setActive(url);menu.classList.remove("open");burger.setAttribute("aria-expanded","false");window.scrollTo(0,0)
}).catch(function(){location.href=url})}
document.addEventListener("click",function(e){var a=e.target.closest("a[data-nav]");
if(!a||e.ctrlKey||e.metaKey||e.shiftKey)return;e.preventDefault();load(a.getAttribute("href"),true)});
window.addEventListener("popstate",function(){load(location.pathname.split("/").pop()||"index.html",false)});
document.addEventListener("submit",function(e){var f=e.target.closest("form[data-demo]");if(!f)return;e.preventDefault();
f.querySelector(".msg").textContent=f.dataset.demo;f.reset()});
})();